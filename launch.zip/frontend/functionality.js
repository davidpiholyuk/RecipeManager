document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('add-recipe-form').addEventListener('submit', function(event) {
        event.preventDefault();

        var name = document.getElementById('recipe-name').value;
        var ingredients = document.getElementById('recipe-ingredients').value;
        var instructions = document.getElementById('recipe-instructions').value;

        fetch(`http://localhost:7071/api/AddRecipe`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                Name: name,
                Ingredients: ingredients,
                Instructions: instructions,
                Favorite: false
            })
        })
        .then(response => response.json())
        .then(data => {
            alert('Recipe added successfully!');
        });
    });

    document.getElementById('get-recipe-form').addEventListener('submit', function(event) {
        event.preventDefault();

        var name = document.getElementById('get-recipe-name').value;

        fetch(`http://localhost:7071/api/recipes/${name}`)
            .then(response => response.json())
            .then(data => {
                // Display the recipe details
                document.getElementById('recipe-details').innerHTML = `
                    <h2>${data.Name}</h2>
                    <p>${data.Ingredients}</p>
                    <p>${data.Instructions}</p>
                `;
        });
    });

    document.getElementById('update-recipe-form').addEventListener('submit', function(event) {
        event.preventDefault();

        var name = document.getElementById('update-recipe-name').value;
        var newName = document.getElementById('update-recipe-newname').value;

        fetch(`http://localhost:7071/api/recipes/${name}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                Name: newName
            })
        })
        .then(response => response.json())
        .then(data => {
            alert('Recipe updated successfully!');
        });
    });

    document.getElementById('favorite-recipe-form').addEventListener('submit', function(event) {
        event.preventDefault();

        var name = document.getElementById('favorite-recipe-name').value;

        fetch(`http://localhost:7071/api/recipes/${name}/favorite`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                Favorite: true
            })
        })
        .then(response => response.json())
        .then(data => {
            alert('Recipe favorited successfully!');
        });
    });
});
